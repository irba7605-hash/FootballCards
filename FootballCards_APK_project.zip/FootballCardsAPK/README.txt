Football Cards Android wrapper project

This folder is an Android Studio / GitHub Actions project, not an APK yet.
To build an APK using GitHub Actions:
1. Create a GitHub repository and upload these project files.
2. Open the repo's Actions tab.
3. Choose "Build APK" and press Run workflow.
4. When it completes, open the run and download the artifact FootballCards-debug-apk.
5. Extract app-debug.apk on your Android phone and install it (allow installation from this source if Android prompts).

The HTML game is bundled offline in app/src/main/assets/index.html.
